# __NAME__

An empty Node.js project.

## Getting started

```bash
npm install
npm run dev
```

The server starts on `http://localhost:3000` (override with `PORT`).
