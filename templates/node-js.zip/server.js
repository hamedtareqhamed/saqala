import http from 'node:http'
import './index.js'

function startServer(port) {
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' })
    res.end('Server running. index.js imported and active.\n')
  })

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      startServer(port + 1)
    } else {
      console.error(err)
    }
  })

  server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`)
  })
}

const PORT = Number(process.env.PORT) || 3000
startServer(PORT)
