import http from 'node:http'
import './index.js'

function startServer(port: number) {
  const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' })
    res.end('Server running. src/index.ts imported and active.\n')
  })

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      startServer(port + 1)
    } else {
      console.error(err)
    }
  })

  server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`)
  })
}

const PORT: number = Number(process.env.PORT) || 3000
startServer(PORT)
